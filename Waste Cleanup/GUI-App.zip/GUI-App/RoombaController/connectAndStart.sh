# nmcli device wifi list
nmcli device wifi connect "cyBOT 11"
cd build
make
./RoombaController
