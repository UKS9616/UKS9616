var HoleManager_8hpp =
[
    [ "HoleManager", "classHoleManager.html", "classHoleManager" ],
    [ "MEASUREMENT_WIDTH", "HoleManager_8hpp.html#a98743a6e40590a591f14abd4bbe2b675", null ],
    [ "sideLength", "HoleManager_8hpp.html#a9e3667c9425085b498f4b8ee21a19595", null ]
];