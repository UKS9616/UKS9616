var Hole_8cpp =
[
    [ "operator<<", "Hole_8cpp.html#a371c0f905489a21d9276bb383a572487", null ]
];