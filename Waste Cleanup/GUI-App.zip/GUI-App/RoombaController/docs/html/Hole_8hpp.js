var Hole_8hpp =
[
    [ "Hole", "classHole.html", "classHole" ],
    [ "HOLE_SIZE", "Hole_8hpp.html#a657e122f8983d0a993ee0266696f1984", null ]
];