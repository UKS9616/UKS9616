var classHole =
[
    [ "Hole", "classHole.html#a4ea8b237954a3decf415e384b042eacd", null ],
    [ "Hole", "classHole.html#a653b2d43ddca456e31c6be921d7077df", null ],
    [ "Hole", "classHole.html#ac73d25f280d747ba04a6e9b90d587d94", null ],
    [ "Hole", "classHole.html#a079e74ec763052a10fedea61a6a5088b", null ],
    [ "Hole", "classHole.html#a90b129019613cc439b9834058f8727b1", null ],
    [ "Hole", "classHole.html#a4ddff9cebed0fa967b3a8ea12aac1195", null ],
    [ "Hole", "classHole.html#a6c5cc5e4efbe73711dab187e00a0a171", null ],
    [ "addPoint", "classHole.html#a39673dc613c45644ff844c7b81709ab9", null ],
    [ "copyDoOperation", "classHole.html#ad224d20fbe2037b97e19344b8f0157e0", null ],
    [ "getOneSquareCorner", "classHole.html#a1b9d48a850759ae1b826b7476c304785", null ],
    [ "getSecondSquareCorner", "classHole.html#ae5ba1de89591495ee62c784c8bcc4b72", null ],
    [ "getSubHolesCopy", "classHole.html#a863918993a62cc90b99a66c48e9e0bdc", null ],
    [ "getSuggestedNodePlacements", "classHole.html#a519b0f73c960b116403ee937a8fb0a3e", null ],
    [ "isFoundHole", "classHole.html#aec56b428187b4a6f5a952463b4029d00", null ],
    [ "isInSquare", "classHole.html#afd4c5c949e5c37e58ff10927e475fcdf", null ],
    [ "lineIntersectsHole", "classHole.html#ae7c69bf5e1d37a1230b50187e7442506", null ],
    [ "offset", "classHole.html#a73735b03496aad26f53879b2c50fcc71", null ],
    [ "pointCouldBeMemberOfHole", "classHole.html#afb912f0b7b58f2074fcbbc50184e39c2", null ],
    [ "registerPointsToHole", "classHole.html#adc6df39c2118fd21749786927800de4b", null ],
    [ "operator<<", "classHole.html#a371c0f905489a21d9276bb383a572487", null ]
];