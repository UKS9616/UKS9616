var classHoleManager =
[
    [ "HoleManager", "classHoleManager.html#a2a70f9e895789105b0b45df164bf6ff6", null ],
    [ "addHole", "classHoleManager.html#ae4fc057aea5dbfc0596b48455beed1e7", null ],
    [ "addHole", "classHoleManager.html#a5c2e0ffae18e961f5ba3f18688ef34bf", null ],
    [ "addPoint", "classHoleManager.html#a317b24d6b0d2b5f843d3cbc4fcf39dd8", null ],
    [ "getHole", "classHoleManager.html#a50df7cfd1e6e527d16b939769317ec50", null ],
    [ "getHoles", "classHoleManager.html#a586843e9065c89985c3b76bc8a2f9003", null ],
    [ "getPointsOnHoles", "classHoleManager.html#ab74e44ccae65e04db4f54a9b44d9655d", null ],
    [ "getSuggestedNodePlacements", "classHoleManager.html#aa0e47cc875c67f9244088d5c895ec725", null ],
    [ "lineIntersectsAnyHoleMeasurement", "classHoleManager.html#a1a77b2aa21fe82b6aa7073aa004e9e6f", null ],
    [ "nodeCollides", "classHoleManager.html#a3b0b1c780a1ed91646e0bcbf1dd23e70", null ],
    [ "offsetAll", "classHoleManager.html#a0a8f51f0c0c0c3af90b3fd0a90ea062e", null ]
];