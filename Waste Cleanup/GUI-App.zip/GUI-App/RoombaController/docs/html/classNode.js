var classNode =
[
    [ "Node", "classNode.html#ab4dbea374a06a1f9ac1e85b8ded1d983", null ],
    [ "getData", "classNode.html#a81895d8b8dfffcc5d220b2d816e7063c", null ],
    [ "SetData", "classNode.html#ab849a0519ed381feaf341d91e3d87b1f", null ]
];