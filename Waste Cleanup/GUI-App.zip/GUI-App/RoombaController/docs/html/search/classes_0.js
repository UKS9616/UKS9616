var searchData=
[
  ['customcompare_0',['CustomCompare',['../structGraph_1_1CustomCompare.html',1,'Graph']]]
];
