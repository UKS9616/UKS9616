var searchData=
[
  ['bot_5fconnect_0',['BOT_CONNECT',['../main_8cpp.html#a69549d0bd46cc467083f3554f3f95955',1,'main.cpp']]],
  ['bot_5fradius_1',['BOT_RADIUS',['../Pose2D_8hpp.html#aa214e157b90ee2b54649c3bb808b4d60',1,'Pose2D.hpp']]]
];
