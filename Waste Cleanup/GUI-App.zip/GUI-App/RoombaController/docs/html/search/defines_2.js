var searchData=
[
  ['hole_5fsize_0',['HOLE_SIZE',['../Hole_8hpp.html#a657e122f8983d0a993ee0266696f1984',1,'Hole.hpp']]]
];
