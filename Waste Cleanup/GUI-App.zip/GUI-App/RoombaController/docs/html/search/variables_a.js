var searchData=
[
  ['sendcondition_0',['sendCondition',['../main_8cpp.html#a4bf7290e131c491bb7def53e3d340b95',1,'main.cpp']]],
  ['sendqueue_1',['sendQueue',['../main_8cpp.html#aa1dd612fc3a4eaae839fbcb1fc0489f3',1,'main.cpp']]]
];
