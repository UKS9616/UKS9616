var searchData=
[
  ['type_0',['type',['../structMove.html#a024fa73d41d4d3830f2565e158a2b521',1,'Move']]]
];
