var structMove =
[
    [ "quantity", "structMove.html#a261f6dd2a4399171b95747f32eb4025e", null ],
    [ "type", "structMove.html#a024fa73d41d4d3830f2565e158a2b521", null ]
];