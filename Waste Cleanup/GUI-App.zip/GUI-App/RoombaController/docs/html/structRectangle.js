var structRectangle =
[
    [ "r1", "structRectangle.html#a9ab0b4bae48e8330e4064bfc2aac696d", null ],
    [ "r2", "structRectangle.html#ab7c029f35f42207f6cd273c7251ff8fb", null ],
    [ "r3", "structRectangle.html#a084cafc6917f1a0881e6e111329a4588", null ],
    [ "r4", "structRectangle.html#ad96df264562ce0b343bc9569ac899b29", null ]
];