var util_8hpp =
[
    [ "doIntersect", "util_8hpp.html#a4e5e5d18b9bfa850378af284c05268df", null ],
    [ "lineIntersectsRectangle", "util_8hpp.html#a913e3a56bee44293842c0d78d7e56634", null ],
    [ "onSegment", "util_8hpp.html#aec2e0e6da52a6460459ffefa1bad0fd3", null ],
    [ "orientation", "util_8hpp.html#aeaeef2ccb49a89c827eeeb25d89a1ff8", null ]
];