cd build
cmake ../
make
./RoombaControllers
